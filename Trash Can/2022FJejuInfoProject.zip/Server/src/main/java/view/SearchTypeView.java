package view;

import persistence.DTO.*;
import service.JProtocol;
import service.SearchTypeService;

import java.util.List;
import java.util.Scanner;

public class SearchTypeView {

    SearchTypeService searchTypeService = new SearchTypeService();

    // 전시회 데이터 전송
    public JProtocol.SendExhibitionPacket read_exhibition_all() {
        // Service
        JProtocol.SendExhibitionPacket sendExhibitionPacket = searchTypeService.e_work_read_all();

        System.out.println("sendExhibitionPacket = " + sendExhibitionPacket); // 이거 다 안 보이는 이유는 protected 때문인듯?
        System.out.println("sendExhibitionPacket.getProtocolData() = " + sendExhibitionPacket.getProtocolData());
        return sendExhibitionPacket;
    }

    public JProtocol.SendGoodRestaurantPacket read_good_restaurant_all() {
        // Service
        JProtocol.SendGoodRestaurantPacket sendGoodRestaurantPacket = searchTypeService.g_work_read_all();

        System.out.println("sendGoodRestaurantPacket = " + sendGoodRestaurantPacket);
        return sendGoodRestaurantPacket;
    }

    public JProtocol.SendHorseridingBackPacket read_horseriding_back_all() {
        // Service
        JProtocol.SendHorseridingBackPacket sendHorseridingBackPacket = searchTypeService.h_work_read_all();

        System.out.println("sendHorseridingBackPacket = " + sendHorseridingBackPacket);
        return sendHorseridingBackPacket;
    }

    public JProtocol.SendNatureSightBackPacket read_nature_sight_all() {
        // Service
        JProtocol.SendNatureSightBackPacket sendNatureSightBackPacket = searchTypeService.n_work_read_all();

        System.out.println("sendNatureSightBackPacket = " + sendNatureSightBackPacket);
        return sendNatureSightBackPacket;
    }

    public JProtocol.SendOllehInformationPacket read_olleh_information_all() {
        //Service
        JProtocol.SendOllehInformationPacket sendOllehInformationPacket = searchTypeService.o_work_read_all();

        System.out.println("sendOllehInformationPacket = " + sendOllehInformationPacket);
        return sendOllehInformationPacket;
    }

    public JProtocol.SendSpotInformationPacket read_spot_information_by_type(String type) {
        // Serivce
        JProtocol.SendSpotInformationPacket sendSpotInformationPacket = searchTypeService.s_work_read_by_type(type);

        System.out.println("sendSpotInformationPacket = " + sendSpotInformationPacket);
        return sendSpotInformationPacket;
    }

}
