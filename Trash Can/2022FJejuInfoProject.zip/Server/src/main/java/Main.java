import service.JProtocol;
import view.*;

import java.io.*;
import java.net.*;


// 지금 HORSEBACK_RIDING으로 테이블이 저장되어 있는데 클래스들은 HORSERIDING_BACK으로 저장되어 있음
// 문제 생길 수도 있으니 참고
public class Main {
    public static void main(String[] args) {

        ServerSocket s = null;
        Socket conn = null;

        try {
            s = new ServerSocket();
            s.setReuseAddress(true);
            InetAddress Address = InetAddress.getLocalHost();
            System.out.println(Address.getHostAddress());
            SocketAddress addr = new InetSocketAddress(Address, 3000);
            s.bind(addr);
            System.out.println("waiting for client");

            while (true) {
                conn = s.accept();
                System.out.println("from ip:" + conn.getInetAddress().getHostAddress() + "port:" + conn.getPort());

                new client_handle(conn).start();
            }
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }

        try {
            s.close();
        } catch (IOException ioException) {
            System.err.println("unable to close");
        }
    }
}

class client_handle extends Thread {
    private Socket conn;
    boolean program_stop = false;

    SearchTypeView searchTypeView = new SearchTypeView();

    client_handle(Socket conn) {
        this.conn = conn;
    }

    public void run() {
        InputStream is;
        ObjectInputStream ois;
        OutputStream os;
        ObjectOutputStream oos;

        boolean program_stop = false;
        try {
            is = conn.getInputStream();
            ois = new ObjectInputStream(is);
            os = conn.getOutputStream();
            oos = new ObjectOutputStream(os);

            do {
                JProtocol.ClientMessagePacket clientMessagePacket =
                        (JProtocol.ClientMessagePacket) ois.readObject();

                switch (clientMessagePacket.getProtocolType()) {
                    case JProtocol.PT_TEMP_TYPE1:
                        switch (clientMessagePacket.getProtocolCode()) {
                            case JProtocol.PT_TEMP_CODE2:
                                JProtocol.SendExhibitionPacket sendExhibitionPacket = searchTypeView.read_exhibition_all();
                                oos.writeObject(sendExhibitionPacket);
                                oos.flush();
                                break;
                        }
                        break;

                    case JProtocol.PT_TEMP_TYPE2:
                        switch (clientMessagePacket.getProtocolCode()) {
                            case JProtocol.PT_TEMP_CODE2:
                                JProtocol.SendGoodRestaurantPacket sendGoodRestaurantPacket = searchTypeView.read_good_restaurant_all();
                                oos.writeObject(sendGoodRestaurantPacket);
                                oos.flush();
                                break;
                        }
                        break;

                    case JProtocol.PT_TEMP_TYPE3:
                        switch (clientMessagePacket.getProtocolCode()) {
                            case JProtocol.PT_TEMP_CODE2:
                                JProtocol.SendHorseridingBackPacket sendHorseridingBackPacket = searchTypeView.read_horseriding_back_all();
                                oos.writeObject(sendHorseridingBackPacket);
                                oos.flush();
                                break;
                        }
                        break;

                    case JProtocol.PT_TEMP_TYPE4:
                        switch (clientMessagePacket.getProtocolCode()) {
                            case JProtocol.PT_TEMP_CODE2:
                                JProtocol.SendNatureSightBackPacket sendNatureSightBackPacket = searchTypeView.read_nature_sight_all();
                                oos.writeObject(sendNatureSightBackPacket);
                                oos.flush();
                                break;
                        }
                        break;

                    case JProtocol.PT_TEMP_TYPE5:
                        switch (clientMessagePacket.getProtocolCode()) {
                            case JProtocol.PT_TEMP_CODE2:
                                JProtocol.SendOllehInformationPacket sendOllehInformationPacket = searchTypeView.read_olleh_information_all();
                                oos.writeObject(sendOllehInformationPacket);
                                oos.flush();
                                break;
                        }
                        break;

                    case JProtocol.PT_TEMP_TYPE6:
                        switch (clientMessagePacket.getProtocolCode()) {
                            case JProtocol.PT_TEMP_CODE2:
                                JProtocol.SendSpotInformationPacket sendSpotInformationPacket = searchTypeView.read_spot_information_by_type(
                                        clientMessagePacket.getProtocolData());
                                oos.writeObject(sendSpotInformationPacket);
                                oos.flush();
                                break;
                        }
                        break;
                }

            } while (!program_stop);

            ois.close();
            os.close();
            oos.close();
            os.close();
            conn.close();

        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }
}
