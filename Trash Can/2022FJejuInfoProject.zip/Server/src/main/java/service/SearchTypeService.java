package service;

import persistence.DAO.*;
import persistence.DTO.*;
import persistence.MybatisConnectionFactory;

import java.util.List;

public class SearchTypeService {
    // 네트워크 관련 필드 (미정)

    // DAO 관련 클래스
    SearchTypeDAO searchTypeDAO = new SearchTypeDAO(MybatisConnectionFactory.getSqlSessionFactory());

    // 데이터 베이스 관련 서비스
    public JProtocol.SendExhibitionPacket e_work_read_all() {
        JProtocol.SendExhibitionPacket sendExhibitionPacket = new JProtocol.SendExhibitionPacket(
                JProtocol.PT_TEMP_TYPE1,
                JProtocol.PT_TEMP_CODE3,
                searchTypeDAO.e_select_all_with_annotation());
        return sendExhibitionPacket;
    }

    public JProtocol.SendGoodRestaurantPacket g_work_read_all() {
        JProtocol.SendGoodRestaurantPacket sendGoodRestaurantPacket = new JProtocol.SendGoodRestaurantPacket(
                JProtocol.PT_TEMP_TYPE2,
                JProtocol.PT_TEMP_CODE3,
                searchTypeDAO.g_select_all_with_annotation());
        return sendGoodRestaurantPacket;
    }

    public JProtocol.SendHorseridingBackPacket h_work_read_all() {
        JProtocol.SendHorseridingBackPacket sendHorseridingBackPacket = new JProtocol.SendHorseridingBackPacket(
                JProtocol.PT_TEMP_TYPE3,
                JProtocol.PT_TEMP_CODE3,
                searchTypeDAO.h_select_basics_all_with_annotation(),
                searchTypeDAO.h_select_details_all_with_annotation());
        return sendHorseridingBackPacket;
    }

    public JProtocol.SendNatureSightBackPacket n_work_read_all() {
        JProtocol.SendNatureSightBackPacket sendNatureSightBackPacket = new JProtocol.SendNatureSightBackPacket(
                JProtocol.PT_TEMP_TYPE4,
                JProtocol.PT_TEMP_CODE3,
                searchTypeDAO.n_select_basics_all_with_annotation(),
                searchTypeDAO.n_select_details_all_with_annotation());
        return sendNatureSightBackPacket;
    }

    public JProtocol.SendOllehInformationPacket o_work_read_all() {
        JProtocol.SendOllehInformationPacket sendOllehInformationPacket = new JProtocol.SendOllehInformationPacket(
                JProtocol.PT_TEMP_TYPE5,
                JProtocol.PT_TEMP_CODE3,
                searchTypeDAO.o_select_basics_all_with_annotation(),
                searchTypeDAO.o_select_details_all_with_annotation());
        return sendOllehInformationPacket;
    }

    public JProtocol.SendSpotInformationPacket s_work_read_by_type(String type) {
        JProtocol.SendSpotInformationPacket sendSpotInformationPacket = new JProtocol.SendSpotInformationPacket(
                JProtocol.PT_TEMP_TYPE6,
                JProtocol.PT_TEMP_CODE3,
                searchTypeDAO.s_select_by_type_with_annotation(type));
        return sendSpotInformationPacket;
    }
}
