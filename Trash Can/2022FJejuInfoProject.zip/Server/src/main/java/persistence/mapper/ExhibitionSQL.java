package persistence.mapper;

import org.apache.ibatis.jdbc.SQL;
import persistence.DTO.ExhibitionDTO;

// 조회만 하기 때문에 의미 없음
public class ExhibitionSQL {
//    public String e_select_all() {
//        SQL sql = new SQL() {{
//            SELECT("*");
//            FROM("exhibition");
//        }};
//        return sql.toString();
//    }
}
