package persistence.mapper;

import org.apache.ibatis.annotations.*;
import persistence.DTO.ExhibitionDTO;
import persistence.DTO.GoodRestaurantDTO;

import java.util.List;

public interface ExhibitionMapper {

    /* 전시관 테이블 전체 READ */
    @Select("SELECT * FROM EXHIBITION")
    @Results(id="exhibitionSet", value= {
            @Result(property = "spotkey", column = "spot_key"),
            @Result(property = "spotcollection", column = "spot_collection")
    })
    List<ExhibitionDTO> get_all_exhibition();

}
