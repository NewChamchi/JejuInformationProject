package persistence.mapper;

import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import persistence.DTO.HorseridingBackDTO;
import persistence.DTO.SpotInformationDTO;

import java.util.List;

public interface HorseridingBackMapper {
    @Select("SELECT * FROM HORSEBACK_RIDING")
    @Results(id="horsebackRidingSet", value={
            @Result(property = "spotkey", column = "spot_key"),
            @Result(property = "spotbusiness", column = "spot_business")
    })
    List<HorseridingBackDTO> get_all_horseback_riding_details();

    @Select("SELECT * FROM SPOT_INFORMATION")
    @Results(id="spotInformationSet", value={
            @Result(property = "spotkey", column = "spot_key"),
            @Result(property = "spotname", column = "spot_name"),
            @Result(property = "spotaddress", column = "spot_address"),
            @Result(property = "spottype", column = "spottype")
    })
    List<SpotInformationDTO> get_all_spot_information();

    @Select("SELECT * FROM SPOT_INFORMATION " +
            "WHERE EXISTS (SELECT SPOT_KEY FROM HORSEBACK_RIDING " +
            "WHERE SPOT_KEY = SPOT_INFORMATION.SPOT_KEY)")
    @ResultMap("spotInformationSet")
    List<SpotInformationDTO> get_all_horseback_riding_basics();
}
