package persistence.mapper;

public class SpotInformationSQL {
}
