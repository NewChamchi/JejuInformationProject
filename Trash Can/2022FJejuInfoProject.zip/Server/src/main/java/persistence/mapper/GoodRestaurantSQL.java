package persistence.mapper;

public class GoodRestaurantSQL {
}
