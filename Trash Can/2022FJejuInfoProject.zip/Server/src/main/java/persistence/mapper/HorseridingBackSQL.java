package persistence.mapper;

public class HorseridingBackSQL {
}
