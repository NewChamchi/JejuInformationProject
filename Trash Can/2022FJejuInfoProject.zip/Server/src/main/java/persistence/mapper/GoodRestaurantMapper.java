package persistence.mapper;

import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import persistence.DTO.GoodRestaurantDTO;

import java.util.List;

public interface GoodRestaurantMapper {
    @Select("SELECT * FROM GOOD_RESTAURANT")
    @Results(id="goodRestaurantSet", value={
            @Result(property = "goodrestaurantkey", column = "good_restaurant_key"),
            @Result(property = "goodrestaurantname", column = "good_restaurant_name"),
            @Result(property = "goodrestaurantaddress", column = "good_restaurant_address"),
            @Result(property = "goodrestaurantphone", column = "good_restaurant_phone"),
            @Result(property = "goodrestaurantmainmenu", column = "good_restaurant_main_menu"),
            @Result(property = "goodrestaurantstate", column = "good_restaurant_state")
    })
    List<GoodRestaurantDTO> get_all_good_restaurant();
}
