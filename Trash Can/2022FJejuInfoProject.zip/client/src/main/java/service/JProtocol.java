package service;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import persistence.DTO.*;

import java.io.Serializable;
import java.util.List;


public class JProtocol {

    public static final int PT_UNDEFINED = -1;
    public static final int PT_EXIT = 0;
    public static final int LEN_PROTOCOL_TYPE = 1; //프로토콜 타입 길이
    public static final int LEN_CODE = 1; //프로토콜 코드 길이

    // TYPE 정보
    public static final int PT_TEMP_TYPE1 = 1;
    public static final int PT_TEMP_TYPE2 = 2;
    public static final int PT_TEMP_TYPE3 = 3;
    public static final int PT_TEMP_TYPE4 = 4;
    public static final int PT_TEMP_TYPE5 = 5;
    public static final int PT_TEMP_TYPE6 = 6;
    // CODE 정보
    public static final int PT_TEMP_CODE1 = 1;
    public static final int PT_TEMP_CODE2 = 2;
    public static final int PT_TEMP_CODE3 = 3;
    @Getter
    @Setter
    @ToString
    public static class Packet implements Serializable {
        protected int protocolType;
        protected int protocolCode;

        public Packet() {
            this.protocolType = PT_UNDEFINED;
            this.protocolCode = PT_UNDEFINED;
        }

        public Packet(int protocolType, int protocolCode) {
            this.protocolType = protocolType;
            this.protocolCode = protocolCode;
        }

        public void setPacket (int protocolType, int protocolCode) {
            this.protocolType = protocolType;
            this.protocolCode = protocolCode;
        }

        public int getProtocolType() {
            return protocolType;
        }

        public int getProtocolCode() {
            return protocolCode;
        }
    }

    public static class ClientMessagePacket extends Packet {
        protected String protocolData;

        public ClientMessagePacket() {
            super();
        }

        public ClientMessagePacket(int protocolType, int protocolCode, String protocolData) {
            super(protocolType, protocolCode);
            this.protocolData = protocolData;
        }

        public void setPacket (int protocolType, int protocolCode, String protocolData) {
            super.setPacket(protocolType, protocolCode);
            this.protocolData = protocolData;
        }

        public String getProtocolData() {
            return protocolData;
        }
    }
    public static class SendExhibitionPacket extends Packet {
        protected List<ExhibitionDTO> protocolData;

        public SendExhibitionPacket(int protocolType, int protocolCode, List<ExhibitionDTO> protocolData) {
            super(protocolType, protocolCode);
            this.protocolData = protocolData;
        }

        public void setPacket (int protocolType, int protocolCode, List<ExhibitionDTO> protocolData) {
            super.setPacket(protocolType, protocolCode);
            this.protocolData = protocolData;
        }

        public List<ExhibitionDTO> getProtocolData() {
            return protocolData;
        }
    }

    public static class SendGoodRestaurantPacket extends Packet {
        protected List<GoodRestaurantDTO> protocolData;

        public SendGoodRestaurantPacket(int protocolType, int protocolCode, List<GoodRestaurantDTO> protocolData) {
            super(protocolType, protocolCode);
            this.protocolData = protocolData;
        }

        public void setPacket (int protocolType, int protocolCode, List<GoodRestaurantDTO> protocolData) {
            super.setPacket(protocolType, protocolCode);
            this.protocolData = protocolData;
        }

        public List<GoodRestaurantDTO> getProtocolData() {
            return protocolData;
        }
    }

    public static class SendHorseridingBackPacket extends Packet {
        protected List<SpotInformationDTO> protocolData1;
        protected List<HorseridingBackDTO> protocolData2;

        public SendHorseridingBackPacket(int protocolType, int protocolCode, List<SpotInformationDTO> protocolData1, List<HorseridingBackDTO> protocolData2) {
            super(protocolType, protocolCode);
            this.protocolData1 = protocolData1;
            this.protocolData2 = protocolData2;
        }

        public void setPacket (int protocolType, int protocolCode,
                               List<SpotInformationDTO> protocolData1, List<HorseridingBackDTO> protocolData2) {
            super.setPacket(protocolType, protocolCode);
            this.protocolData1 = protocolData1;
            this.protocolData2 = protocolData2;
        }

        public List<SpotInformationDTO> getProtocolData1() {
            return protocolData1;
        }

        public List<HorseridingBackDTO> getProtocolData2() {
            return protocolData2;
        }
    }

    public static class SendNatureSightBackPacket extends Packet {
        protected List<SpotInformationDTO> protocolData1;
        protected List<NatureSightDTO> protocolData2;

        public SendNatureSightBackPacket(int protocolType, int protocolCode, List<SpotInformationDTO> protocolData1, List<NatureSightDTO> protocolData2) {
            super(protocolType, protocolCode);
            this.protocolData1 = protocolData1;
            this.protocolData2 = protocolData2;
        }

        public void setPacket (int protocolType, int protocolCode,
                               List<SpotInformationDTO> protocolData1, List<NatureSightDTO> protocolData2) {
            super.setPacket(protocolType, protocolCode);
            this.protocolData1 = protocolData1;
            this.protocolData2 = protocolData2;
        }

        public List<SpotInformationDTO> getProtocolData1() {
            return protocolData1;
        }

        public List<NatureSightDTO> getProtocolData2() {
            return protocolData2;
        }
    }

    public static class SendOllehInformationPacket extends Packet {
        protected List<SpotInformationDTO> protocolData1;
        protected List<OllehInformationDTO> protocolData2;

        public SendOllehInformationPacket(int protocolType, int protocolCode, List<SpotInformationDTO> protocolData1, List<OllehInformationDTO> protocolData2) {
            super(protocolType, protocolCode);
            this.protocolData1 = protocolData1;
            this.protocolData2 = protocolData2;
        }

        public void setPacket (int protocolType, int protocolCode,
                               List<SpotInformationDTO> protocolData1, List<OllehInformationDTO> protocolData2) {
            super.setPacket(protocolType, protocolCode);
            this.protocolData1 = protocolData1;
            this.protocolData2 = protocolData2;
        }

        public List<SpotInformationDTO> getProtocolData1() {
            return protocolData1;
        }

        public List<OllehInformationDTO> getProtocolData2() {
            return protocolData2;
        }
    }

    public static class SendSpotInformationPacket extends Packet {
        protected List<SpotInformationDTO> protocolData;

        public SendSpotInformationPacket(int protocolType, int protocolCode, List<SpotInformationDTO> protocolData) {
            super(protocolType, protocolCode);
            this.protocolData = protocolData;
        }

        public void setPacket (int protocolType, int protocolCode, List<SpotInformationDTO> protocolData) {
            super.setPacket(protocolType, protocolCode);
            this.protocolData = protocolData;
        }

        public List<SpotInformationDTO> getProtocolData() {
            return protocolData;
        }
    }

    public static class SendSpotInformationListPacket extends Packet {
        protected List<List<SpotInformationDTO>> protocolData;

        public SendSpotInformationListPacket(int protocolType, int protocolCode, List<List<SpotInformationDTO>> protocolData) {
            super(protocolType, protocolCode);
            this.protocolData = protocolData;
        }

        public void setPacket (int protocolType, int protocolCode, List<List<SpotInformationDTO>> protocolData) {
            super.setPacket(protocolType, protocolCode);
            this.protocolData = protocolData;
        }

        public List<List<SpotInformationDTO>> getProtocolData() {
            return protocolData;
        }
    }

}
