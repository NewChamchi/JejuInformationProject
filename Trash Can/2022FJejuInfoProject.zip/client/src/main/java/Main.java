import persistence.DTO.ExhibitionDTO;
import service.JProtocol;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
        InetAddress addr = InetAddress.getLocalHost();
        String localname = addr.getHostName();
        String ip = "192.168.0.4";
        System.out.println(localname + ip);
        Socket socket = new Socket(ip, 3000); // 아이피 확인은 실행 -> cmd -> ipconfig 후 IPv4를 복사하면 됨
        System.out.println("connect");
        boolean program_stop = false;
        OutputStream os = socket.getOutputStream();
        InputStream is = socket.getInputStream();
        ObjectOutputStream oos = new ObjectOutputStream(os);
        ObjectInputStream ois = new ObjectInputStream(is);
        Scanner sc = new Scanner(System.in);

        do {
            PrintMenu();
            int menu_result = sc.nextInt();
            JProtocol.ClientMessagePacket clientMessagePacket = new JProtocol.ClientMessagePacket();
            switch (menu_result) {
                case 1:
                    clientMessagePacket.setPacket(JProtocol.PT_TEMP_TYPE1, JProtocol.PT_TEMP_CODE2, "");
                    oos.writeObject(clientMessagePacket);
                    oos.flush();
                    break;
                case 2:
                    clientMessagePacket.setPacket(JProtocol.PT_TEMP_TYPE2, JProtocol.PT_TEMP_CODE2, "");
                    oos.writeObject(clientMessagePacket);
                    oos.flush();
                    break;
                case 3:
                    clientMessagePacket.setPacket(JProtocol.PT_TEMP_TYPE3, JProtocol.PT_TEMP_CODE2, "");
                    oos.writeObject(clientMessagePacket);
                    oos.flush();
                    break;
                case 4:
                    clientMessagePacket.setPacket(JProtocol.PT_TEMP_TYPE4, JProtocol.PT_TEMP_CODE2, "");
                    oos.writeObject(clientMessagePacket);
                    oos.flush();
                    break;
                case 5:
                    clientMessagePacket.setPacket(JProtocol.PT_TEMP_TYPE5, JProtocol.PT_TEMP_CODE2, "");
                    oos.writeObject(clientMessagePacket);
                    oos.flush();
                    break;
                case 6:
                    clientMessagePacket.setPacket(JProtocol.PT_TEMP_TYPE6, JProtocol.PT_TEMP_CODE2, "농원");
                    oos.writeObject(clientMessagePacket);
                    oos.flush();
                    break;
                case 7:
                    clientMessagePacket.setPacket(JProtocol.PT_TEMP_TYPE6, JProtocol.PT_TEMP_CODE2, "오름");
                    oos.writeObject(clientMessagePacket);
                    oos.flush();
                    break;
                case 8:
                    clientMessagePacket.setPacket(JProtocol.PT_TEMP_TYPE6, JProtocol.PT_TEMP_CODE2, "무장애 여행지");
                    oos.writeObject(clientMessagePacket);
                    oos.flush();
                    break;
                case 9:
                    program_stop = true;
                    continue;
                default :
                    System.out.println("long number");
                    continue;
            }
            JProtocol.Packet serverMessagePacket = (JProtocol.Packet) ois.readObject();
            //test
            /*/
            System.out.println("serverMessagePacket = " + serverMessagePacket);
             //*/
            switch (serverMessagePacket.getProtocolType()) {
                case JProtocol.PT_TEMP_TYPE1:
                    switch (serverMessagePacket.getProtocolCode()) {
                        case JProtocol.PT_TEMP_CODE3:
                            System.out.println("((JProtocol.SendExhibitionPacket) serverMessagePacket).getProtocolData() = " + ((JProtocol.SendExhibitionPacket) serverMessagePacket).getProtocolData());
                            break;
                    }
                    break;
                case JProtocol.PT_TEMP_TYPE2:
                    switch (serverMessagePacket.getProtocolCode()) {
                        case JProtocol.PT_TEMP_CODE3:
                            System.out.println("((JProtocol.SendGoodRestaurantPacket)serverMessagePacket).getProtocolData() = " + ((JProtocol.SendGoodRestaurantPacket)serverMessagePacket).getProtocolData());
                            break;
                    }
                    break;
                case JProtocol.PT_TEMP_TYPE3:
                    switch (serverMessagePacket.getProtocolCode()) {
                        case JProtocol.PT_TEMP_CODE3:
                            System.out.println("((JProtocol.SendHorseridingBackPacket) serverMessagePacket).getProtocolData1() = " + ((JProtocol.SendHorseridingBackPacket) serverMessagePacket).getProtocolData1());
                            System.out.println("((JProtocol.SendHorseridingBackPacket) serverMessagePacket).getProtocolData2() = " + ((JProtocol.SendHorseridingBackPacket) serverMessagePacket).getProtocolData2());
                            break;
                    }
                    break;
                case JProtocol.PT_TEMP_TYPE4:
                    switch (serverMessagePacket.getProtocolCode()) {
                        case JProtocol.PT_TEMP_CODE3:
                            System.out.println("((JProtocol.SendNatureSightBackPacket) serverMessagePacket).getProtocolData1() = " + ((JProtocol.SendNatureSightBackPacket) serverMessagePacket).getProtocolData1());
                            System.out.println("((JProtocol.SendNatureSightBackPacket) serverMessagePacket).getProtocolData2() = " + ((JProtocol.SendNatureSightBackPacket) serverMessagePacket).getProtocolData2());
                            break;
                    }
                    break;
                case JProtocol.PT_TEMP_TYPE5:
                    switch (serverMessagePacket.getProtocolCode()) {
                        case JProtocol.PT_TEMP_CODE3:
                            System.out.println("((JProtocol.SendOllehInformationPacket)serverMessagePacket).getProtocolData1() = " + ((JProtocol.SendOllehInformationPacket)serverMessagePacket).getProtocolData1());
                            System.out.println("((JProtocol.SendOllehInformationPacket)serverMessagePacket).getProtocolData2() = " + ((JProtocol.SendOllehInformationPacket)serverMessagePacket).getProtocolData2());
                            break;
                    }
                    break;
                case JProtocol.PT_TEMP_TYPE6:
                    switch (serverMessagePacket.getProtocolCode()) {
                        case JProtocol.PT_TEMP_CODE3:
                            System.out.println("((JProtocol.SendSpotInformationPacket)serverMessagePacket).getProtocolData() = " + ((JProtocol.SendSpotInformationPacket)serverMessagePacket).getProtocolData());
                            break;
                    }
                    break;
            }

        } while (!program_stop);

        is.close();
        ois.close();
        os.close();
        oos.close();
        socket.close();
        sc.close();


    }

    public static void PrintMenu() {
        System.out.println("1. 전시관 조회");
        System.out.println("2. 모범음식점 조회");
        System.out.println("3. 승마장 조회");
        System.out.println("4. 자연 명소 조회");
        System.out.println("5. 올레길 조회");
        System.out.println("6. 농원 조회");
        System.out.println("7. 오름 조회");
        System.out.println("8. 무장애 여행지 조회");
        System.out.println("9. 프로그램 종료");
        System.out.print("메뉴 선택 : ");
    }
}
